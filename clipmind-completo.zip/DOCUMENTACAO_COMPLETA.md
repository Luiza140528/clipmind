# 📚 Documentação Completa ClipMind

---

## 📖 ÍNDICE

1. [Guia de Uso](#guia-de-uso)
2. [Guia do Desenvolvedor](#guia-do-desenvolvedor)
3. [Roadmap Completo](#roadmap-completo)
4. [FAQ Técnico](#faq-técnico)

---

# 1. GUIA DE USO

## Para Políticos / Criadores

### ✅ Começando

**Passo 1: Criar Conta**
1. Acesse https://clipmind.com
2. Clique "Testar Grátis"
3. Preencha: Email + Senha
4. Pronto! Você tem acesso imediato

**Plano Free oferece:**
- 3 cortes por mês
- Transcrição automática
- Marca ClipMind discreta
- Download em HD

### 📹 Seu Primeiro Corte

**Passo 1: Fazer Upload**
1. Na dashboard, clique "Novo Vídeo"
2. Cole URL do YouTube ou faça upload
3. Clique "Processar"

**Passo 2: Esperar Processamento**
- Vídeos de 30min: ~2-3 minutos
- Vídeos de 1h: ~5-10 minutos
- Você recebe notificação quando fica pronto

**Passo 3: Revisar Cortes**
- ClipMind gera 5-7 cortes automáticos
- Cada corte tem um motivo (por que vai viralizar)
- Você pode ver preview antes de baixar

**Passo 4: Baixar e Publicar**
- Clique no corte que quer
- Botão "Download" (HD 1080x1920)
- Publique direto no TikTok/Reels/Shorts

### 🎨 Design dos Cortes

Todos os cortes têm:
- **Fundo:** Dark Navy (#0D1B2A) premium
- **Legendas:** Gold (#C9A84C) em destaque
- **Fonte:** Grande e legível (23pt)
- **Watermark:** "ClipMind" discreto (planos pagos não têm)

### 💰 Upgrading

**Quando estiver pronto:**
1. Clique "Upgrade" na dashboard
2. Escolha: Starter (R$47) ou Pro (R$97)
3. Complete pagamento no Mercado Pago
4. Acesso ativado **imediatamente**

**Starter oferece:**
- 30 cortes por mês
- ❌ Sem marca ClipMind
- Biblioteca completa (histórico)
- Suporte por email

**Pro oferece:**
- Cortes **ilimitados**
- ❌ Sem marca
- Biblioteca + busca avançada
- Agendamento automático (em breve)
- Suporte prioritário

### 📚 Biblioteca

Todos os cortes ficam salvos na "Biblioteca":
- Veja cortes antigos
- Reutilize trechos
- Organize por campanha
- Compartilhe com equipe (Pro)

---

# 2. GUIA DO DESENVOLVEDOR

## Setup Local

### Pré-requisitos
- Node.js 18+
- Git
- PostgreSQL (via Supabase)
- OpenAI API key (Whisper)
- Anthropic API key (Claude)
- Mercado Pago credenciais

### 1. Clonar e Instalar

```bash
git clone https://github.com/Luiza140528/clipmind.git
cd clipmind/backend
npm install
```

### 2. Setup Supabase

```bash
# 1. Criar projeto em https://app.supabase.com
# 2. Na aba SQL Editor, rodar schema.sql inteiro
# 3. Copiar credenciais pro .env.local
```

### 3. Configurar .env.local

```env
NODE_ENV=development
PORT=8080
BASE_URL=http://localhost:8080

# Supabase
SUPABASE_URL=https://xxxxx.supabase.co
SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...

# APIs
OPENAI_API_KEY=sk-proj-...
ANTHROPIC_API_KEY=sk-ant-...

# Mercado Pago
MERCADO_PAGO_ACCESS_TOKEN=APP_prod_...
MERCADO_PAGO_PUBLIC_KEY=APP_PUBLIC_...

# Segurança
WEBHOOK_SECRET=seu-secret-aleatorio
```

### 4. Rodar Localmente

```bash
npm run dev
```

Server roda em `http://localhost:8080`

### 5. Testar

```bash
# Health check
curl http://localhost:8080/health

# Signup
curl -X POST http://localhost:8080/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"123456"}'
```

---

## Arquitetura

```
clipmind/
├── backend/
│   ├── src/
│   │   ├── server.js           # Express principal
│   │   ├── routes/
│   │   │   ├── auth.js         # Signup/Login
│   │   │   ├── billing.js      # Mercado Pago
│   │   │   └── clips.js        # Gerenciar cortes
│   │   ├── services/
│   │   │   ├── youtube.js      # Download video
│   │   │   ├── transcription.js # Whisper
│   │   │   ├── clipAnalysis.js # Claude analysis
│   │   │   ├── videoEditing.js # FFmpeg
│   │   │   ├── storage.js      # Supabase storage
│   │   │   └── mercado-pago.js # Pagamentos
│   │   ├── jobs/
│   │   │   └── cleanup.js      # Deletar vídeos após 30d
│   │   └── middleware/
│   │       ├── auth.js
│   │       └── errorHandler.js
│   ├── package.json
│   ├── .env.example
│   ├── Dockerfile
│   └── schema.sql
├── frontend/
│   ├── index.html              # Landing page
│   ├── css/style.css
│   └── js/app.js
└── README.md
```

---

## Stack Técnica

| Camada | Tecnologia |
|--------|-----------|
| Frontend | HTML5 + CSS3 + Vanilla JS |
| Backend | Node.js 18 + Express 4.18 |
| Auth | Supabase Auth (JWT) |
| Database | PostgreSQL (via Supabase) |
| Storage | Supabase Storage (vídeos) |
| Transcrição | OpenAI Whisper API |
| IA Análise | Anthropic Claude Haiku |
| Edição Vídeo | FFmpeg + yt-dlp |
| Pagamento | Mercado Pago (Checkout) |
| Hospedagem | Railway (backend) + Netlify (frontend) |
| CDN | Supabase Storage |

---

## API Endpoints

### Autenticação

**POST /api/auth/signup**
```json
{
  "email": "user@email.com",
  "password": "senha123",
  "name": "Nome"
}
```

**POST /api/auth/login**
```json
{
  "email": "user@email.com",
  "password": "senha123"
}
```

### Processamento

**POST /api/process**
```json
{
  "youtube_url": "https://youtube.com/watch?v=..."
}
```

Response:
```json
{
  "job_id": "job_123",
  "status": "processing"
}
```

**GET /api/process/:job_id**
Status do processamento

### Clips

**GET /api/clips**
Lista todos os cortes do user

**GET /api/clips/:clip_id**
Detalhes de um corte

**DELETE /api/clips/:clip_id**
Deletar um corte

### Billing

**POST /api/billing/checkout**
Criar preferência de pagamento

**GET /api/billing/status**
Ver subscription atual

**POST /api/billing/cancel**
Cancelar subscription

---

## Ambiente de Produção

### Deploy Railway

1. Conectar GitHub (repo privado)
2. Railway detecta `Dockerfile`
3. Adicionar variáveis de ambiente
4. Deploy automático em cada push

### Custom Domain

```
Backend: api.clipmind.com
Frontend: clipmind.com
```

### Logs

```bash
# Ver logs do Railway
railway logs

# Ver logs local
npm run dev
```

---

# 3. ROADMAP COMPLETO

## Fase 1: MVP (Junho - Julho 2026) ✅ AGORA

### Objetivos
- Lançar versão funcional
- 100 usuários beta
- Validar com políticos
- Gerar primeiros R$10k/mês

### Features
- ✅ Upload vídeo (YouTube + arquivo)
- ✅ Transcrição Whisper
- ✅ IA identifica momentos (Claude)
- ✅ FFmpeg gera cortes
- ✅ Storage Supabase
- ✅ Auth básico
- ✅ Pagamento Mercado Pago
- ✅ Landing page
- ⏳ Dashboard simples

### Métricas
- Videos processados: 500+
- Taxa de sucesso: 98%
- NPS: 8.5+

---

## Fase 2: Crescimento (Agosto - Dezembro 2026)

### Objetivos
- Atingir R$25k/mês
- 1.000 usuários ativos
- Integração com redes sociais
- Analytics básico

### Features
- 📊 Dashboard com analytics
- 📱 Mobile app (iOS/Android)
- 🔗 Publicação automática (TikTok API)
- 👥 Multi-user (time)
- 🎯 Segmentação de audience
- 💬 Chat support
- 🔔 Notificações

### Métricas
- Video/user: 50/mês
- Retention 30d: 70%
- Churn: <5%

---

## Fase 3: Escala (2027)

### Objetivos
- R$100k+/mês
- 10.000+ usuários
- Modelo B2B (agências)
- Integração com ferramentas

### Features
- 🤖 IA Preditiva (prever virais)
- 📈 Benchmarking (seus cortes vs concorrentes)
- 🌐 Multi-idioma
- ⚙️ Webhooks customizados
- 🔌 API pública
- 📊 White-label (agências)

### Métricas
- ARR: 1.2M
- CAC: R$200
- LTV: 15x CAC

---

# 4. FAQ TÉCNICO

## Geral

**P: Quanto custa rodar?**
A: ~R$500/mês (Supabase + Railway + APIs)

**P: Preciso de GPU?**
A: Não. FFmpeg roda em CPU normal.

**P: Qual é o tempo máximo de vídeo?**
A: ~2 horas. Acima disso, aumenta custo de Whisper.

**P: Posso usar em produção agora?**
A: Sim, tá pronto. Mas comece com beta fechado (100-200 users).

---

## Processamento

**P: Por que demora 2-3 minutos?**
A: Whisper leva ~1min por 10min de vídeo + Claude análise + FFmpeg rendering.

**P: Posso processar vários vídeos ao mesmo tempo?**
A: Sim. Backend aguenta 50+ jobs simultâneos.

**P: O que acontece se falhar?**
A: Tentamos novamente 3x automaticamente. Se falhar, salvamos erro e notificamos user.

---

## Segurança

**P: Meus vídeos são privados?**
A: Sim. RLS (Row Level Security) ativo no Supabase. Só você acessa.

**P: Vocês deletam os vídeos?**
A: Sim. Após 30 dias, deletamos arquivo local. Storage Supabase mantém por 1 ano.

**P: Como valido tokens?**
A: JWT via Supabase Auth. Cada request valida Authorization header.

---

## Pagamento

**P: Quanto Mercado Pago cobra?**
A: ~2.99% + R$0.30 por transação (valores BR).

**P: Posso usar outro gateway?**
A: Sim. Código tá modular. Troca `mercado-pago.js` por outro.

**P: Como refundo?**
A: Manual via painel Mercado Pago. ClipMind não faz automático (ainda).

---

## Escalabilidade

**P: Aguenta 10.000 usuários?**
A: Sim. Railway escalável. Supabase aguenta 100k+ requests/mês.

**P: Preciso de cache?**
A: Não no MVP. Redis é opção futura se tiver N+1 queries.

**P: Como monitoro performance?**
A: Railway dashboard + Supabase Analytics.

---

## Desenvolvimento

**P: Posso adicionar novos modelos de IA?**
A: Sim. Cria novo service em `/services/` e integra em `server.js`.

**P: Como testo localmente sem APIs reais?**
A: Use mocks em `__mocks__/` directory. Veja Jest docs.

**P: Qual é a coverage de testes?**
A: MVP tem 0%. Próxima fase: 80%+.

---

## Deployment

**P: Como faço rollback?**
A: Railway permite deploy de qualquer commit anterior.

**P: Posso usar múltiplos ambientes?**
A: Sim. Cria branches (dev, staging, prod) com envs separados.

**P: Como monitoro erros?**
A: Console.log (MVP). Próxima fase: Sentry.

---

## Custo

### Estimativa Mensal (100-500 users)

| Serviço | Uso | Custo |
|---------|-----|-------|
| Railway | 2GB RAM | R$50 |
| Supabase | 500GB storage | R$200 |
| Whisper | 1000 min/mês | R$150 |
| Claude | 1M tokens/mês | R$100 |
| Banda | 500GB download | R$0 (Supabase) |
| **TOTAL** | | **~R$500** |

Com 100 users pagos (R$47/mês): **Lucro = (100 × 47) - 500 = R$4.200**

---

## Próximos Passos

1. ✅ Código pronto
2. ⏳ Deploy Railway
3. ⏳ Testar com 10-20 políticos
4. ⏳ Ajustar based em feedback
5. ⏳ Lançamento público

---

**Status:** Documentação Completa ✅  
**Última atualização:** 15 de junho de 2026  
**Próximo review:** Após fase 1 beta
