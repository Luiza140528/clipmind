// mercado-pago.js - Integração Mercado Pago para ClipMind
// Endpoints: /api/billing/checkout, /api/billing/webhook, /api/billing/status

const axios = require('axios');
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

// ============================================
// CONFIGURAÇÃO MERCADO PAGO
// ============================================

const MP_API = 'https://api.mercadopago.com/v1';
const MP_ACCESS_TOKEN = process.env.MERCADO_PAGO_ACCESS_TOKEN;
const MP_PUBLIC_KEY = process.env.MERCADO_PAGO_PUBLIC_KEY;

const PLANS = {
  free: {
    name: 'Free',
    price: 0,
    credits: 3,
    clips_per_month: 3,
  },
  starter: {
    name: 'Starter',
    price: 4700, // em centavos: R$47.00
    credits: 30,
    clips_per_month: 30,
  },
  pro: {
    name: 'Pro',
    price: 9700, // em centavos: R$97.00
    credits: 999,
    clips_per_month: -1, // ilimitado
  },
  agency: {
    name: 'Agência',
    price: 29700, // em centavos: R$297.00
    credits: 9999,
    clips_per_month: -1, // ilimitado
  },
};

// ============================================
// CRIAR PREFERÊNCIA DE PAGAMENTO (CHECKOUT)
// ============================================

async function createCheckoutPreference(user_id, plan_id, user_email) {
  try {
    const plan = PLANS[plan_id];

    if (!plan) {
      throw new Error('Invalid plan');
    }

    if (plan.price === 0) {
      // Free plan - sem pagamento
      await updateUserSubscription(user_id, plan_id, null, 'active');
      return {
        success: true,
        message: 'Free plan activated',
        redirect_url: `${process.env.BASE_URL}?plan=free`,
      };
    }

    // Criar preferência no Mercado Pago
    const preference = {
      items: [
        {
          id: plan_id,
          title: `ClipMind ${plan.name} - Assinatura Mensal`,
          description: `${plan.clips_per_month === -1 ? 'Cortes ilimitados' : plan.clips_per_month + ' cortes/mês'}`,
          category_id: 'digital_content',
          quantity: 1,
          unit_price: plan.price / 100, // converter de centavos pra reais
          currency_id: 'BRL',
        },
      ],
      payer: {
        email: user_email,
        identification: {
          type: 'CPF',
        },
      },
      payment_methods: {
        default_payment_method_id: null,
        excluded_payment_types: [],
        installments: 1,
      },
      back_urls: {
        success: `${process.env.BASE_URL}/billing/success?user_id=${user_id}&plan=${plan_id}`,
        failure: `${process.env.BASE_URL}/billing/failed?user_id=${user_id}&plan=${plan_id}`,
        pending: `${process.env.BASE_URL}/billing/pending?user_id=${user_id}&plan=${plan_id}`,
      },
      auto_return: 'approved',
      notification_url: `${process.env.BASE_URL}/api/webhooks/mercado-pago`,
      external_reference: `clipmind_${user_id}_${plan_id}_${Date.now()}`,
      expires: true,
      expiration_date_from: new Date().toISOString(),
      expiration_date_to: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24h
    };

    const response = await axios.post(`${MP_API}/checkout/preferences`, preference, {
      headers: {
        Authorization: `Bearer ${MP_ACCESS_TOKEN}`,
        'Content-Type': 'application/json',
      },
    });

    const preference_id = response.data.id;
    const init_point = response.data.init_point;

    // Salvar preference no Supabase (pra rastrear depois)
    await supabase.from('mercado_pago_preferences').insert({
      user_id,
      preference_id,
      plan_id,
      status: 'pending',
      created_at: new Date().toISOString(),
    });

    console.log(`[MP] Preference created: ${preference_id} for user ${user_id}`);

    return {
      success: true,
      preference_id,
      init_point, // URL pra redirecionar user
    };
  } catch (error) {
    console.error(`[MP] Error creating preference: ${error.message}`);
    throw error;
  }
}

// ============================================
// WEBHOOK - RECEBER NOTIFICAÇÃO DE PAGAMENTO
// ============================================

async function handleMercadoPagoWebhook(data) {
  try {
    const { id, type, data: payment_data } = data;

    console.log(`[MP] Webhook received: type=${type}, id=${id}`);

    // Se for payment, verificar o status
    if (type === 'payment') {
      const payment_id = id;

      // Buscar detalhes do pagamento
      const payment = await axios.get(`${MP_API}/payments/${payment_id}`, {
        headers: {
          Authorization: `Bearer ${MP_ACCESS_TOKEN}`,
        },
      });

      const { status, external_reference, additional_info } = payment.data;

      console.log(`[MP] Payment ${payment_id} status: ${status}`);

      // Parse external_reference: clipmind_userId_planId_timestamp
      const [, user_id, plan_id] = external_reference.split('_');

      if (status === 'approved') {
        // ✅ PAGAMENTO APROVADO
        await updateUserSubscription(user_id, plan_id, payment_id, 'active');
        console.log(`[MP] Subscription activated for user ${user_id}`);
      } else if (status === 'pending') {
        // ⏳ PENDENTE (boleto, pix, etc)
        await updateUserSubscription(user_id, plan_id, payment_id, 'pending');
        console.log(`[MP] Subscription pending for user ${user_id}`);
      } else if (status === 'rejected' || status === 'cancelled') {
        // ❌ REJEITADO
        await updateUserSubscription(user_id, plan_id, payment_id, 'failed');
        console.log(`[MP] Subscription failed for user ${user_id}`);
      }
    }

    return { success: true };
  } catch (error) {
    console.error(`[MP] Webhook error: ${error.message}`);
    return { success: false, error: error.message };
  }
}

// ============================================
// ATUALIZAR SUBSCRIPTION DO USER
// ============================================

async function updateUserSubscription(user_id, plan_id, mercado_pago_id, status) {
  try {
    const plan = PLANS[plan_id];

    if (!plan) {
      throw new Error('Invalid plan');
    }

    // Atualizar tabela users
    await supabase
      .from('users')
      .update({
        plan: plan_id,
        credits: plan.credits,
        subscription_id: mercado_pago_id,
        updated_at: new Date().toISOString(),
      })
      .eq('id', user_id);

    // Criar/atualizar registro em subscriptions
    const now = new Date();
    const renews_at = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000); // 30 dias

    if (status === 'active') {
      await supabase.from('subscriptions').upsert({
        user_id,
        plan: plan_id,
        mercado_pago_id,
        status: 'active',
        price: plan.price / 100,
        started_at: now.toISOString(),
        renews_at: renews_at.toISOString(),
        created_at: now.toISOString(),
        updated_at: now.toISOString(),
      });
    } else if (status === 'pending') {
      await supabase.from('subscriptions').upsert({
        user_id,
        plan: plan_id,
        mercado_pago_id,
        status: 'pending',
        price: plan.price / 100,
        started_at: now.toISOString(),
        renews_at: renews_at.toISOString(),
        created_at: now.toISOString(),
        updated_at: now.toISOString(),
      });
    } else if (status === 'failed') {
      await supabase.from('subscriptions').upsert({
        user_id,
        plan: plan_id,
        mercado_pago_id,
        status: 'cancelled',
        created_at: now.toISOString(),
        updated_at: now.toISOString(),
      });

      // Voltar pro plan free
      await supabase
        .from('users')
        .update({
          plan: 'free',
          credits: 3,
          updated_at: now.toISOString(),
        })
        .eq('id', user_id);
    }

    console.log(`[MP] User ${user_id} subscription updated: ${plan_id} - ${status}`);
    return true;
  } catch (error) {
    console.error(`[MP] Error updating subscription: ${error.message}`);
    throw error;
  }
}

// ============================================
// VERIFICAR STATUS DA SUBSCRIPTION
// ============================================

async function getUserSubscriptionStatus(user_id) {
  try {
    const { data: user, error: userError } = await supabase
      .from('users')
      .select('plan, credits, subscription_id')
      .eq('id', user_id)
      .single();

    if (userError) {
      throw new Error('User not found');
    }

    const { data: subscription, error: subError } = await supabase
      .from('subscriptions')
      .select('*')
      .eq('user_id', user_id)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    return {
      user_id,
      plan: user.plan,
      credits: user.credits,
      subscription: subscription || null,
    };
  } catch (error) {
    console.error(`[MP] Error fetching subscription: ${error.message}`);
    throw error;
  }
}

// ============================================
// CANCELAR SUBSCRIPTION
// ============================================

async function cancelSubscription(user_id) {
  try {
    // Atualizar user pra plan free
    await supabase
      .from('users')
      .update({
        plan: 'free',
        credits: 3,
        subscription_id: null,
        updated_at: new Date().toISOString(),
      })
      .eq('id', user_id);

    // Marcar subscription como cancelled
    await supabase
      .from('subscriptions')
      .update({
        status: 'cancelled',
        cancelled_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq('user_id', user_id)
      .eq('status', 'active');

    console.log(`[MP] Subscription cancelled for user ${user_id}`);
    return { success: true };
  } catch (error) {
    console.error(`[MP] Error cancelling subscription: ${error.message}`);
    throw error;
  }
}

// ============================================
// EXPORTS
// ============================================

module.exports = {
  createCheckoutPreference,
  handleMercadoPagoWebhook,
  updateUserSubscription,
  getUserSubscriptionStatus,
  cancelSubscription,
  PLANS,
};
