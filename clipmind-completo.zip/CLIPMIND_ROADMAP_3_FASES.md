# 🚀 ClipMind — Roadmap de Fases

**Visão:** Transforme vídeos em cortes. Organize conhecimento. Construa memória.

---

## 📊 As 3 Fases do ClipMind

### **FASE 1: ClipMind Cortes** (Semanas 1-4)
**Objetivo:** MVP de cortes virais — validar mercado com políticos

**O que faz:**
- ✅ Upload vídeo (YouTube/arquivo)
- ✅ Transcrição automática (Whisper)
- ✅ Identificação automática de melhores momentos (Claude Haiku)
- ✅ Geração de cortes com legenda (FFmpeg)
- ✅ Download direto

**Público:** Políticos, assessores, criadores

**Preços:**
- Free: R$0 (3 cortes/mês + marca)
- Starter: R$47/mês (30 cortes)
- Pro: R$97/mês (ilimitado)
- Agência: R$297/mês (múltiplos usuários)

**Stack:**
- Frontend: HTML/JS (Netlify)
- Backend: Node.js + Express (Railway)
- Banco: Supabase Auth + Storage
- Transcrição: Whisper API
- IA: Claude Haiku
- Edição: FFmpeg
- Pagamento: Mercado Pago

**Métricas de sucesso:**
- 50+ usuários ativos
- R$5k/mês recorrente
- 98%+ taxa de sucesso nos processamentos

---

### **FASE 2: ClipMind Grafo** (Semanas 5-8)
**Objetivo:** Construir knowledge graph — organizar narrativas

**O que faz ALÉM dos cortes:**
- ✅ Extração automática de entidades (pessoas, leis, temas)
- ✅ Extração de relações (defende, critica, propõe)
- ✅ Extração de claims (afirmações com timestamps)
- ✅ Vetorização de claims (embeddings OpenAI)
- ✅ Dashboard: Radar de Narrativas
- ✅ Histórico: "O que esse político já disse sobre saúde?"
- ✅ Busca semântica: "Encontre todas as propostas sobre educação"

**Novo público:**
- Agências de comunicação política
- Assessores de imprensa
- Jornalistas investigativos

**Preços (add-on ao Fase 1):**
- Starter + Grafo: +R$30/mês
- Pro + Grafo: +R$50/mês
- Agência + Grafo: +R$150/mês

**Stack novo:**
- Embeddings: OpenAI text-embedding-3-small
- Vector DB: pgvector (Supabase)
- Busca semântica: Similaridade de cosseno
- Dashboard: React/Chart.js

**Métricas de sucesso:**
- 20+ usuários com Grafo ativo
- Grafo processa 100+ claims/vídeo
- Busca semântica com >90% relevância

---

### **FASE 3: ClipMind Auditoria** (Semanas 9+)
**Objetivo:** Auditar consistência discursiva — construir memória

**O que faz ALÉM das fases anteriores:**
- ✅ Motor de Consistency Checker (detecta contradições)
- ✅ Comparação semântica (claim novo vs. histórico)
- ✅ Alertas de reputação (avisa quando há contradição)
- ✅ Relatório de Narrativa (timeline completa)
- ✅ Watchdog automático (monitora tema X ao longo do tempo)
- ✅ Oportunidades (gaps narrativos que o político pode explorar)
- ✅ Score de Consistência (0-100: quão consistente é o discurso?)

**Novo público:**
- Candidatos (análise de oponentes)
- Think tanks e pesquisa política
- Consultores estratégicos
- Comunicação corporativa

**Preços (premium):**
- Auditoria Starter: R$197/mês
- Auditoria Pro: R$497/mês
- Auditoria Enterprise: R$1.497/mês (ilimitado + relatórios customizados)

**Stack novo:**
- LLM para análise: Claude Opus (análises mais profundas)
- Job queue: Trigger.dev (processamento assíncrono de auditoria)
- Relatórios: PDF generation (WeasyPrint ou similar)
- Alertas: Email + Push notification

**Métricas de sucesso:**
- 10+ clientes premium
- R$20k+/mês em receita de auditoria
- Consistency Checker com >95% de acurácia
- Taxa de detecção de contradições em tempo real

---

## 🗺️ Visão completa

```
CLIPMIND v1.0 (Fase 1)
│
├─ Cortes virais automáticos
├─ Transcrição + IA
└─ Monetização: R$47-297/mês

        ↓

CLIPMIND v2.0 (Fase 2)
│
├─ Tudo da v1 +
├─ Knowledge Graph (entidades, relações, claims)
├─ Busca semântica
├─ Dashboard de narrativas
└─ Monetização: +R$30-150/mês add-on

        ↓

CLIPMIND v3.0 (Fase 3)
│
├─ Tudo da v2 +
├─ Consistency Checker (detecta contradições)
├─ Auditoria de reputação
├─ Alertas automáticos
├─ Relatórios premium
└─ Monetização: R$197-1.497/mês (premium)
```

---

## 💰 Projeção de Receita

**Cenário otimista:**

| Fase | Tempo | Usuários | Ticket médio | Receita mensal |
|---|---|---|---|---|
| **Fase 1** | Mês 1-4 | 100 | R$80 | R$8.000 |
| **Fase 2** | Mês 5-8 | 150 | R$120 (base + add-on) | R$18.000 |
| **Fase 3** | Mês 9+ | 50 premium + 100 base | R$300 premium + R$80 base | R$23.000 |

**Total projetado após 9 meses:** R$23k+/mês recorrente

---

## ⚠️ Riscos e Mitigação

**Risco 1:** Fase 2 é complexa (embeddings, vector search)
- **Mitigação:** Usar Supabase pgvector (managed), não build from scratch

**Risco 2:** Fase 3 precisa de acurácia alta no Consistency Checker
- **Mitigação:** Beta com 10 usuários primeiro, iterar modelo

**Risco 3:** 2026 é ano eleitoral — depois perde demanda política
- **Mitigação:** Fase 1 captura político; Fase 2-3 já visa criadores/jornalistas/agências

---

## 📅 Timeline

| Semana | O quê | Responsável |
|---|---|---|
| 1-2 | Backend + frontend base (Fase 1) | Você |
| 3-4 | Testes, landing refinement, launch MVP | Você |
| 5-6 | Extração de conhecimento (Fase 2) | Você + Claude |
| 7-8 | Dashboard + busca semântica (Fase 2) | Você |
| 9-10 | Consistency Checker (Fase 3) | Você + Claude |
| 11-12 | Auditoria + relatórios (Fase 3) | Você |

---

## 🎯 O que você começa AGORA (hoje)

**APENAS FASE 1:**
1. Backend Node.js (server.js)
2. Autenticação Supabase
3. Endpoint de processamento
4. Frontend simples (upload → download)
5. Integração Mercado Pago
6. Landing page + launch

**Não pensa em Fase 2/3 ainda.** Primeiro foca em validar que:
- ✅ Vídeo processa rápido
- ✅ Cortes ficam bons
- ✅ Político paga
- ✅ Receita cresce

Depois, quando Fase 1 tiver 50+ usuários pagantes, você pensa em Fase 2.

---

**Status:** Pronto para começar Fase 1
**Próximo passo:** Backend Node.js (server.js base)
