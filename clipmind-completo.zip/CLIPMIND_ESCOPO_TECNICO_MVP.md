# 🎬 ClipMind — Escopo Técnico MVP

**Produto:** Plataforma SaaS que transforma vídeos longos em cortes virais usando IA

**Nicho inicial:** Político (2026)  
**Expansão:** Criadores, podcasters, coaches, agências  
**Prazo:** 4 semanas

---

## 📋 Stack Confirmada

| Camada | Tecnologia | Motivo |
|---|---|---|
| **Frontend** | HTML/JS vanilla (Netlify) | Rápido, você já conhece |
| **Backend** | Node.js + Express (Railway) | Já rodando no CONTIS |
| **Transcrição** | Whisper API (OpenAI) | Whisper PT é excelente |
| **IA** | Claude Haiku | Barato, rápido, você usa |
| **Edição de vídeo** | FFmpeg | Já usa no CrimeOS |
| **Download de vídeo** | yt-dlp | Open source, confiável |
| **Autenticação** | Supabase Auth | Já integrado no CONTIS |
| **Banco de dados** | Supabase (PostgreSQL) | Já tem conta ativa |
| **Armazenamento** | Supabase Storage | Free até 1GB, depois pago |
| **Pagamento** | Mercado Pago | Já integrado no DESVIA |
| **Hospedagem** | Railway + Netlify | Infraestrutura atual |

---

## 🔧 Arquitetura do Sistema

### Fluxo Principal

```
Usuario cola URL YouTube
         ↓
  Autenticação (Supabase)
         ↓
  Validação de créditos/plano
         ↓
  Backend cria job de processamento
         ↓
  [PROCESSAMENTO PARALELO]
  ├─ yt-dlp: baixa áudio/vídeo
  ├─ Whisper: transcreve
  ├─ Claude Haiku: analisa + identifica trechos
  └─ FFmpeg: recorta + queima legenda
         ↓
  Salva arquivo em Supabase Storage
         ↓
  Atualiza status no banco
         ↓
  User recebe link de download
```

---

## 📁 Estrutura de Pastas

```
clipmind/
├── backend/
│   ├── src/
│   │   ├── server.js                 # Express principal
│   │   ├── routes/
│   │   │   ├── auth.js              # Login/signup
│   │   │   ├── process.js           # Endpoint de processamento
│   │   │   ├── clips.js             # Listar/baixar cortes
│   │   │   └── plans.js             # Planos e créditos
│   │   ├── services/
│   │   │   ├── youtube.js           # yt-dlp wrapper
│   │   │   ├── transcription.js     # Whisper API
│   │   │   ├── clipAnalysis.js      # Claude Haiku
│   │   │   ├── videoEditing.js      # FFmpeg wrapper
│   │   │   ├── storage.js           # Supabase Storage
│   │   │   └── payment.js           # Mercado Pago
│   │   ├── utils/
│   │   │   ├── logger.js
│   │   │   └── validators.js
│   │   └── config.js
│   ├── package.json
│   └── .env.example
│
├── frontend/
│   ├── index.html
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   ├── app.js                   # App principal
│   │   ├── auth.js                  # Login/logout
│   │   ├── processor.js             # Form de URL
│   │   ├── dashboard.js             # Dashboard do user
│   │   └── billing.js               # Planos
│   └── assets/
│       └── [imagens, icones]
│
├── landing/
│   ├── index.html                   # Landing page
│   ├── css/
│   │   └── landing.css
│   └── assets/
│
└── README.md
```

---

## 🔌 Endpoints Backend

### Autenticação

**POST /api/auth/signup**
```json
{
  "email": "politico@email.com",
  "password": "123456",
  "name": "João Silva"
}
```
Response: `{ user_id, token }`

**POST /api/auth/login**
```json
{
  "email": "politico@email.com",
  "password": "123456"
}
```
Response: `{ user_id, token }`

**GET /api/auth/me**
Headers: `Authorization: Bearer token`
Response: `{ user_id, email, name, plan, credits }`

---

### Processamento de Vídeo

**POST /api/process**
```json
{
  "youtube_url": "https://youtube.com/watch?v=...",
  "num_clips": 5,
  "min_duration": 15,
  "max_duration": 60
}
```

Response (imediato):
```json
{
  "job_id": "uuid-12345",
  "status": "processing",
  "estimated_time": "2-3 minutos"
}
```

**GET /api/process/:job_id**
Response:
```json
{
  "job_id": "uuid-12345",
  "status": "completed|processing|failed",
  "clips": [
    {
      "id": "clip-1",
      "title": "Melhor momento",
      "reason": "Pico emocional + engagement alto",
      "url": "https://storage.supabase.io/...",
      "duration": 45,
      "created_at": "2026-06-14T10:30:00Z"
    }
  ],
  "error": null
}
```

**DELETE /api/process/:job_id**
Cancela processamento em andamento

---

### Gerenciamento de Clips

**GET /api/clips**
Headers: `Authorization: Bearer token`
Response: Lista todos os clips do usuário com paginação

**GET /api/clips/:clip_id/download**
Redireciona pra arquivo no Supabase Storage

**DELETE /api/clips/:clip_id**
Deleta clip e libera storage

---

### Planos e Créditos

**GET /api/plans**
Response:
```json
{
  "plans": [
    {
      "id": "free",
      "name": "Free",
      "price": 0,
      "clips_per_month": 3,
      "watermark": true
    },
    {
      "id": "starter",
      "name": "Starter",
      "price": 47,
      "clips_per_month": 30,
      "watermark": false
    },
    {
      "id": "pro",
      "name": "Pro",
      "price": 97,
      "clips_per_month": -1,
      "watermark": false
    }
  ]
}
```

**POST /api/billing/checkout**
```json
{
  "plan_id": "starter"
}
```
Response: Link do Mercado Pago

**GET /api/billing/status**
Status da assinatura do usuário

---

## 🧠 Lógica Claude Haiku

### Prompt para Análise de Momentos

```
Você é um especialista em identificar momentos virais em vídeos políticos.

Transcrição: [TRANSCRIPT AQUI]

Timestamps (em segundos): [ARRAY DE TIMESTAMPS]

Sua tarefa:
1. Identificar os 5 MELHORES momentos pra viralizar
2. Para cada momento, explicar por quê (emocional? informativo? polêmico? engraçado?)
3. Retornar em JSON com timestamps exatos e motivos

Critérios de viralização pra político:
- Momentos de força/convicção
- Citações memoráveis
- Contradições do adversário
- Dados impactantes
- Piadas/descontrações
- Promessas/propostas claras

Responda APENAS em JSON, sem markdown:
{
  "clips": [
    {
      "start": 120,
      "end": 175,
      "reason": "Promessa clara + tom confiante",
      "appeal": "alto"
    }
  ]
}
```

---

## 🎥 Processamento FFmpeg

### Geração de Corte com Legenda

```bash
ffmpeg \
  -i video.mp4 \
  -ss 120 -to 175 \
  -vf "subtitles=legenda.srt:force_style='FontSize=20,PrimaryColour=&HFFFFFF&,OutlineColour=&H000000&'" \
  -c:v libx264 -preset fast \
  -c:a aac \
  output.mp4
```

### Specs do Output

- **Codificação:** H.264 + AAC
- **Resolução:** 1080x1920 (vertical pra TikTok/Reels)
- **FPS:** 30
- **Bitrate:** 5000k (balanceado entre qualidade e tamanho)
- **Legenda:** Branca com contorno preto, tamanho 20pt
- **Tamanho máximo:** 100MB

---

## 💾 Banco de Dados (Supabase)

### Tabela: users
```sql
CREATE TABLE users (
  id UUID PRIMARY KEY,
  email VARCHAR UNIQUE NOT NULL,
  name VARCHAR,
  plan VARCHAR DEFAULT 'free',
  credits INT DEFAULT 0,
  subscription_id VARCHAR,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

### Tabela: processing_jobs
```sql
CREATE TABLE processing_jobs (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  youtube_url TEXT,
  status VARCHAR DEFAULT 'pending', -- pending, processing, completed, failed
  num_clips INT,
  error_message TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

### Tabela: clips
```sql
CREATE TABLE clips (
  id UUID PRIMARY KEY,
  job_id UUID REFERENCES processing_jobs(id),
  user_id UUID REFERENCES users(id),
  title VARCHAR,
  reason TEXT,
  start_time INT,
  end_time INT,
  storage_url TEXT,
  duration INT,
  file_size INT,
  created_at TIMESTAMP DEFAULT NOW()
);
```

### Tabela: subscriptions
```sql
CREATE TABLE subscriptions (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  plan VARCHAR,
  mercado_pago_id VARCHAR,
  status VARCHAR, -- active, cancelled
  started_at TIMESTAMP,
  renews_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);
```

---

## 💳 Integração Mercado Pago

### Fluxo

1. User clica em "Upgrade para Pro"
2. Backend cria preferência no Mercado Pago com webhook
3. Redireciona user pra checkout Mercado Pago
4. User paga
5. Webhook retorna ao backend
6. Backend atualiza `plan` e `credits` do user

### Webhook esperado

```json
{
  "id": 123456,
  "topic": "payment",
  "resource": "/v1/payments/123456"
}
```

Backend valida e atualiza subscription do user.

---

## 🔐 Variáveis de Ambiente (.env)

```env
# Supabase
SUPABASE_URL=https://xxxxx.supabase.co
SUPABASE_KEY=eyJxxxxxxxxx

# OpenAI Whisper
OPENAI_API_KEY=sk-xxxxxxxxxxxxx

# Anthropic Claude
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxx

# Mercado Pago
MERCADO_PAGO_ACCESS_TOKEN=APP_xxxxxxxxxxxxx
MERCADO_PAGO_PUBLIC_KEY=APP_PUBLIC_xxxxxxxxxxxxx

# YouTube (opcional, pra contornar rate limits)
YOUTUBE_API_KEY=xxxxxxxxxxxxx

# Server
PORT=8080
NODE_ENV=production
BASE_URL=https://clipmind.com

# Storage
STORAGE_MAX_SIZE_MB=100
```

---

## 📊 Planos e Preços

| Plano | Preço | Cortes/mês | Marca | Legenda | Agendamento |
|---|---|---|---|---|---|
| **Free** | R$0 | 3 | ✅ | ✅ | ❌ |
| **Starter** | R$47 | 30 | ❌ | ✅ | ❌ |
| **Pro** | R$97 | Ilimitado | ❌ | ✅ + Custom | ✅ |
| **Agência** | R$297 | Ilimitado | ❌ | ✅ + Custom | ✅ + Multi-user |

---

## ⚡ Performance Targets

| Métrica | Target |
|---|---|
| Transcrição | 1 min (vídeo 30min) |
| Análise Claude | 30s |
| Corte + legenda FFmpeg | 1-2 min |
| **Total por vídeo** | **3-4 min** |
| Tempo resposta API | <200ms |
| Uptime | 99.5% |

---

## 🧪 MVP Validação

**Semana 1-2:** Você testa com 3-5 vídeos de políticos reais. Se funcionar, vai pra prototipo.

**Semana 3:** Landing page + inicio de divulgação.

**Semana 4:** Beta com 10 usuários políticos.

---

## 🚀 Deploy Checklist

- [ ] Repository no GitHub (privado)
- [ ] Railway conectado (auto-deploy)
- [ ] Variáveis de ambiente configuradas
- [ ] Supabase pronto (tabelas criadas)
- [ ] Mercado Pago em sandbox testado
- [ ] Whisper API key ativa
- [ ] Claude API key ativa
- [ ] yt-dlp instalado em Railway
- [ ] FFmpeg instalado em Railway
- [ ] Netlify conectado pra frontend
- [ ] SSL/HTTPS ativo
- [ ] Rate limiting configurado
- [ ] Logs estruturados ativo
- [ ] Backup do banco automático

---

## 📌 Notas Importantes

1. **Processamento assíncrono:** Não espera tudo na mesma requisição. Retorna job_id, user consulta status depois.

2. **Rate limiting:** Free: 3 vídeos/mês. Starter: 30/mês. Pro: ilimitado (com throttle de 10 simultâneos).

3. **Armazenamento:** Clips gerados ficam em Supabase Storage por 30 dias. Depois deletar automaticamente.

4. **FFmpeg em Railway:** Precisa instalar como buildpack ou usar Docker com ffmpeg incluído.

5. **Fallback pra Whisper local:** Se Whisper API cair, usar `faster-whisper` (grátis, local).

6. **Marca d'água:** No free, adicionar overlay com logo ClipMind (10% da tela, canto inferior).

---

## 🎯 Métricas pra Monitorar

- Número de vídeos processados/dia
- Taxa de sucesso (% que não falham)
- Tempo médio de processamento
- Armazenamento total usado
- Taxa de conversão (free → pago)
- Churn (% que cancela)
- NPS (satisfação do user)

---

**Status:** Pronto pra começar o backend
**Próximo passo:** Montar repositório + estrutura Node.js
