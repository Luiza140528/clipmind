# 📚 Documentação Completa da API ClipMind

**Base URL:** `https://api.clipmind.com` (produção) ou `http://localhost:8080/api` (local)

**Autenticação:** Bearer Token (JWT) no header `Authorization: Bearer YOUR_TOKEN`

---

## 🔐 AUTENTICAÇÃO

### POST `/auth/signup`
**Criar nova conta**

**Request:**
```json
{
  "email": "usuario@example.com",
  "password": "senha123456",
  "name": "João Silva"
}
```

**Response (201):**
```json
{
  "user_id": "uuid",
  "email": "usuario@example.com",
  "name": "João Silva",
  "plan": "free",
  "credits": 3,
  "created_at": "2026-06-15T18:27:00Z"
}
```

**Erros:**
- `400` - Email já registrado
- `400` - Senha muito curta (mín. 6 caracteres)
- `500` - Erro ao criar conta

---

### POST `/auth/login`
**Fazer login**

**Request:**
```json
{
  "email": "usuario@example.com",
  "password": "senha123456"
}
```

**Response (200):**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIs...",
  "user_id": "uuid",
  "email": "usuario@example.com",
  "plan": "free",
  "credits": 3,
  "expires_in": 86400
}
```

**Erros:**
- `401` - Email ou senha incorretos
- `404` - Usuário não encontrado

---

### GET `/auth/me`
**Obter dados do usuário logado**

**Request Header:**
```
Authorization: Bearer {access_token}
```

**Response (200):**
```json
{
  "user_id": "uuid",
  "email": "usuario@example.com",
  "name": "João Silva",
  "plan": "free",
  "credits": 3,
  "subscription": {
    "plan_id": "free",
    "status": "active",
    "renews_at": "2026-07-15T18:27:00Z"
  },
  "created_at": "2026-06-15T18:27:00Z",
  "updated_at": "2026-06-15T18:27:00Z"
}
```

**Erros:**
- `401` - Token inválido ou expirado

---

### POST `/auth/logout`
**Fazer logout**

**Request Header:**
```
Authorization: Bearer {access_token}
```

**Response (200):**
```json
{
  "message": "Logout bem-sucedido"
}
```

---

## 🎬 PROCESSAMENTO DE VÍDEOS

### POST `/process`
**Iniciar processamento de vídeo**

**Request Header:**
```
Authorization: Bearer {access_token}
Content-Type: application/json
```

**Request Body:**
```json
{
  "youtube_url": "https://www.youtube.com/watch?v=...",
  "title": "Meu Vídeo (opcional)",
  "appeal": "resposta_emocional"
}
```

**Parâmetros:**
- `youtube_url` (string, obrigatório): URL do YouTube ou arquivo local
- `title` (string, opcional): Título do vídeo
- `appeal` (string, opcional): Tipo de apelo - `força`, `promessas`, `crítica`, `dados`, `piada`, `citação`, `resposta_emocional`, `auto`

**Response (202):**
```json
{
  "job_id": "uuid",
  "status": "queued",
  "message": "Vídeo enfileirado para processamento",
  "created_at": "2026-06-15T18:27:00Z"
}
```

**Erros:**
- `401` - Não autenticado
- `402` - Créditos insuficientes
- `400` - URL inválida
- `422` - Arquivo muito grande (máx 2GB)

---

### GET `/process/{job_id}`
**Verificar status do processamento**

**Request Header:**
```
Authorization: Bearer {access_token}
```

**Response (200):**
```json
{
  "job_id": "uuid",
  "status": "processing",
  "progress": 45,
  "message": "Transcrevendo áudio...",
  "clips_found": 3,
  "estimated_completion": "2026-06-15T18:35:00Z"
}
```

**Status possíveis:**
- `queued` - Aguardando processamento
- `downloading` - Baixando vídeo
- `transcribing` - Transcrevendo áudio
- `analyzing` - Analisando com IA
- `generating` - Gerando cortes
- `uploading` - Enviando para armazenamento
- `completed` - Concluído com sucesso
- `failed` - Erro no processamento

**Erros:**
- `401` - Não autenticado
- `404` - Job não encontrado

---

## 📹 GERENCIAMENTO DE CLIPS

### GET `/clips`
**Listar todos os cortes do usuário**

**Request Header:**
```
Authorization: Bearer {access_token}
```

**Query Parameters (opcional):**
- `limit` (int, default 50): Máximo de resultados
- `offset` (int, default 0): Deslocamento para paginação
- `sort` (string, default "created_at"): Campo para ordenação (created_at, duration, title)
- `order` (string, default "desc"): Ordem (asc, desc)

**Response (200):**
```json
{
  "clips": [
    {
      "id": "uuid",
      "title": "Momento Viral 1",
      "reason": "resposta_emocional",
      "duration": 45,
      "file_size": 125000000,
      "status": "ready",
      "url": "https://storage.clipmind.com/clips/...",
      "thumbnail": "https://storage.clipmind.com/thumbs/...",
      "created_at": "2026-06-15T18:30:00Z"
    }
  ],
  "total": 25,
  "limit": 50,
  "offset": 0
}
```

**Erros:**
- `401` - Não autenticado

---

### GET `/clips/{clip_id}`
**Obter detalhes de um corte específico**

**Request Header:**
```
Authorization: Bearer {access_token}
```

**Response (200):**
```json
{
  "id": "uuid",
  "title": "Momento Viral 1",
  "reason": "resposta_emocional",
  "duration": 45,
  "file_size": 125000000,
  "status": "ready",
  "url": "https://storage.clipmind.com/clips/...",
  "thumbnail": "https://storage.clipmind.com/thumbs/...",
  "parent_job_id": "uuid",
  "metadata": {
    "video_duration": 1200,
    "start_time": 450,
    "end_time": 495,
    "transcript": "..."
  },
  "created_at": "2026-06-15T18:30:00Z"
}
```

**Erros:**
- `401` - Não autenticado
- `404` - Clip não encontrado

---

### DELETE `/clips/{clip_id}`
**Deletar um corte**

**Request Header:**
```
Authorization: Bearer {access_token}
```

**Response (200):**
```json
{
  "message": "Clip deletado com sucesso",
  "clip_id": "uuid"
}
```

**Erros:**
- `401` - Não autenticado
- `404` - Clip não encontrado

---

### PATCH `/clips/{clip_id}`
**Editar metadados de um corte**

**Request Header:**
```
Authorization: Bearer {access_token}
Content-Type: application/json
```

**Request Body:**
```json
{
  "title": "Novo título",
  "reason": "piada"
}
```

**Response (200):**
```json
{
  "id": "uuid",
  "title": "Novo título",
  "reason": "piada",
  "updated_at": "2026-06-15T18:32:00Z"
}
```

---

### GET `/clips/{clip_id}/download`
**Baixar um corte em MP4**

**Request Header:**
```
Authorization: Bearer {access_token}
```

**Response (200):**
- Arquivo MP4 (aplicação/vnd-mp4)

**Erros:**
- `401` - Não autenticado
- `404` - Clip não encontrado

---

## 💳 FATURAMENTO

### POST `/billing/checkout`
**Criar link de checkout Mercado Pago**

**Request Header:**
```
Authorization: Bearer {access_token}
Content-Type: application/json
```

**Request Body:**
```json
{
  "plan_id": "starter",
  "user_email": "usuario@example.com"
}
```

**Planos disponíveis:**
- `free` (R$0/mês) - 3 créditos
- `starter` (R$47/mês) - 30 créditos
- `pro` (R$97/mês) - ilimitado
- `agency` (R$297/mês) - ilimitado + multi-user

**Response (201):**
```json
{
  "checkout_url": "https://www.mercadopago.com.br/checkout/...",
  "preference_id": "mp_pref_uuid",
  "expires_at": "2026-06-15T19:27:00Z"
}
```

**Erros:**
- `401` - Não autenticado
- `400` - Plano inválido

---

### GET `/billing/status`
**Obter status da assinatura**

**Request Header:**
```
Authorization: Bearer {access_token}
```

**Response (200):**
```json
{
  "user_id": "uuid",
  "plan_id": "starter",
  "status": "active",
  "credits": 25,
  "credits_used": 5,
  "created_at": "2026-05-15T18:27:00Z",
  "renews_at": "2026-07-15T18:27:00Z",
  "next_billing_date": "2026-07-15",
  "payment_method": "credit_card"
}
```

**Erros:**
- `401` - Não autenticado

---

### POST `/billing/cancel`
**Cancelar assinatura**

**Request Header:**
```
Authorization: Bearer {access_token}
```

**Response (200):**
```json
{
  "message": "Assinatura cancelada",
  "refund_status": "processed",
  "plan_downgrade": "free",
  "effective_date": "2026-06-15T18:27:00Z"
}
```

---

### POST `/webhooks/mercado-pago`
**Webhook para notificações de pagamento (Mercado Pago)**

**Header:**
```
X-Signature: {signature}
Content-Type: application/json
```

**Request Body:**
```json
{
  "action": "payment.created",
  "data": {
    "id": "mp_payment_id"
  }
}
```

**Processamentos:**
- `payment.created` - Pagamento iniciado
- `payment.updated` - Pagamento atualizado
- `plan.created` - Plano criado
- `plan.updated` - Plano atualizado

---

## 📊 ANALYTICS

### GET `/analytics`
**Obter dados de analytics**

**Request Header:**
```
Authorization: Bearer {access_token}
```

**Query Parameters (opcional):**
- `period` (string, default "30d"): `7d`, `30d`, `90d`, `all`

**Response (200):**
```json
{
  "period": "30d",
  "total_clips": 25,
  "processed_clips": 23,
  "failed_clips": 2,
  "avg_processing_time": 45,
  "success_rate": 92,
  "credits_used": 15,
  "storage_used": 3750000000,
  "peak_hours": ["19:00", "20:00", "21:00"],
  "popular_appeal": "resposta_emocional",
  "recent_activity": [
    {
      "clip_id": "uuid",
      "title": "Momento Viral",
      "status": "completed",
      "created_at": "2026-06-15T18:30:00Z"
    }
  ]
}
```

---

## ❌ CÓDIGOS DE ERRO

### 400 - Bad Request
```json
{
  "error": "Invalid request",
  "message": "YouTube URL is invalid",
  "code": "INVALID_URL"
}
```

### 401 - Unauthorized
```json
{
  "error": "Unauthorized",
  "message": "Token expired",
  "code": "TOKEN_EXPIRED"
}
```

### 402 - Payment Required
```json
{
  "error": "Insufficient credits",
  "message": "You need 1 credit but have 0",
  "code": "NO_CREDITS"
}
```

### 404 - Not Found
```json
{
  "error": "Not found",
  "message": "Clip not found",
  "code": "CLIP_NOT_FOUND"
}
```

### 422 - Unprocessable Entity
```json
{
  "error": "Validation failed",
  "message": "File size exceeds 2GB limit",
  "code": "FILE_TOO_LARGE"
}
```

### 429 - Too Many Requests
```json
{
  "error": "Rate limited",
  "message": "Too many requests. Try again in 60 seconds",
  "code": "RATE_LIMITED"
}
```

### 500 - Internal Server Error
```json
{
  "error": "Internal server error",
  "message": "Something went wrong. Try again later",
  "code": "INTERNAL_ERROR"
}
```

---

## 🔄 FLUXOS PRINCIPAIS

### Fluxo 1: Criar Conta e Processar Vídeo

1. **POST `/auth/signup`** - Criar conta
2. **POST `/auth/login`** - Fazer login
3. **POST `/process`** - Iniciar processamento
4. **GET `/process/{job_id}`** - Monitorar status (polling a cada 2s)
5. **GET `/clips`** - Listar cortes quando concluído
6. **GET `/clips/{clip_id}/download`** - Baixar corte

---

### Fluxo 2: Fazer Upgrade

1. **POST `/billing/checkout`** - Criar checkout
2. Usuário redireciona para Mercado Pago
3. **Webhook `/webhooks/mercado-pago`** - Processa pagamento
4. **GET `/auth/me`** - Confirmar novo plano
5. **POST `/process`** - Agora com novos créditos

---

## 🔐 Rate Limits

- **Free:** 5 requisições/minuto, 1 processamento/dia
- **Starter:** 30 requisições/minuto, 10 processamentos/dia
- **Pro:** 100 requisições/minuto, ilimitado
- **Agency:** 500 requisições/minuto, ilimitado

---

## 📥 Exemplos com cURL

### Login
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"senha123"}'
```

### Processar Vídeo
```bash
curl -X POST http://localhost:8080/api/process \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"youtube_url":"https://youtube.com/watch?v=..."}'
```

### Listar Clips
```bash
curl -X GET http://localhost:8080/api/clips?limit=10 \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

## 📞 Suporte

- **Email:** support@clipmind.com
- **WhatsApp:** +55 98 99999-9999 (plano Pro+)
- **Chat:** Dentro do dashboard
