# 🛠️ ClipMind — Stack Técnica (Revisão Final)

**MVP Fase 1:** Cortes virais + Biblioteca + Branding

---

## 📋 STACK CONFIRMADA

### Frontend
- **Framework:** HTML/JS vanilla (sem framework pesado)
- **Hospedagem:** Netlify (Drop ou Connect ao GitHub)
- **CSS:** Vanilla CSS (já tem design pronto)
- **Responsividade:** Mobile-first (você usa Android)
- **Auth:** Supabase Auth (integrado)

**Por quê:** Você já domina. Rápido de deployar. Zero complexidade.

---

### Backend
- **Runtime:** Node.js (v18+)
- **Framework:** Express.js
- **Hospedagem:** Railway (já usa em CONTIS)
- **Port:** 8080 (padrão)
- **Auto-deploy:** GitHub → Railway (automático)

**Por quê:** Já tem infrastructure setup. Fast deployment.

---

### Banco de Dados
- **Primary:** Supabase (PostgreSQL gerenciado)
- **Auth:** Supabase Auth (integrado)
- **Storage:** Supabase Storage (para vídeos/cortes)
- **Vectors:** pgvector (para busca semântica — Fase 2)

**Por quê:** Gerenciado. Sem DevOps. Já tem conta.

**Conexão:**
```
SUPABASE_URL=https://xxxxx.supabase.co
SUPABASE_KEY=eyJxxxxxxx (anon key)
SUPABASE_SERVICE_ROLE=eyJxxxxxxx (service role pra backend)
```

---

### APIs Externas

#### 1. **Transcrição**
- **API:** OpenAI Whisper
- **Modelo:** whisper-1 (melhor pra PT-BR)
- **Custo:** ~$0.02 por minuto de áudio
- **Timeout:** até 25MB arquivo

```
OPENAI_API_KEY=sk-xxxxxxxxxxxxx
```

**Alternativa local:** `faster-whisper` (se API cair, fallback)

---

#### 2. **IA para análise de momentos**
- **API:** Anthropic Claude
- **Modelo:** claude-haiku-4-5-20251001 (rápido + barato)
- **Custo:** ~$0.80 por 1M input tokens
- **Uso:** Análise de transcript → identificação de momentos

```
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxx
```

**Por quê Haiku e não Sonnet?**
- Haiku é 5x mais rápido
- Haiku custa 1/10 do preço
- MVP não precisa de análise profunda (Haiku é suficiente)

**Upgrade futuro:** Sonnet (Fase 2, pra análise mais sofisticada)

---

#### 3. **Download de vídeo**
- **Tool:** yt-dlp (open source)
- **Suporte:** YouTube, Facebook, qualquer URL com vídeo
- **Instalação em Railway:** Buildbpack ou Docker com ffmpeg

```bash
npm install yt-dlp
```

**Alternativa:** `youtube-dl` (mais lento, mas funciona)

---

#### 4. **Edição de vídeo**
- **Tool:** FFmpeg (open source)
- **Funções:** Cortar vídeo + queimar legenda
- **Instalação Railway:** Dockerfile com ffmpeg

```bash
ffmpeg -i input.mp4 -ss 00:02:00 -to 00:03:45 \
  -vf "subtitles=legenda.srt:force_style='...'" \
  output.mp4
```

**Specs do output:**
- Codec: libx264 (H.264)
- Áudio: AAC
- Resolução: 1080x1920 (vertical)
- FPS: 30
- Bitrate: 5000k

---

#### 5. **Pagamento**
- **Gateway:** Mercado Pago
- **Fluxo:** User → Create Preference → Redirect pra MP → Webhook de confirmação
- **Webhooks:** ClipMind recebe notificação de pagamento

```
MERCADO_PAGO_ACCESS_TOKEN=APP_xxxxxxxxxxxxx
MERCADO_PAGO_PUBLIC_KEY=APP_PUBLIC_xxxxxxxxxxxxx
```

**Integração:** 
- `/api/billing/checkout` cria preferência
- Webhook em `/api/webhooks/mercado-pago` atualiza subscription no banco

---

#### 6. **Armazenamento de vídeos**
- **Storage:** Supabase Storage (integrado ao banco)
- **Bucket:** `clipmind-videos`
- **Acesso:** Via Supabase client SDK
- **Retenção:** 30 dias (delete automático via cron)

```javascript
supabase.storage
  .from('clipmind-videos')
  .upload(`${user_id}/${clip_id}.mp4`, file)
```

---

## 🔧 DEPENDÊNCIAS NPM (package.json)

```json
{
  "dependencies": {
    "express": "^4.18.2",
    "supabase": "^2.38.0",
    "dotenv": "^16.3.1",
    "axios": "^1.6.0",
    "openai": "^4.20.0",
    "anthropic": "^0.9.0",
    "yt-dlp": "^1.0.0",
    "fluent-ffmpeg": "^2.1.2",
    "node-cron": "^3.0.2",
    "cors": "^2.8.5",
    "helmet": "^7.1.0"
  }
}
```

---

## 📁 ESTRUTURA DO REPOSITÓRIO

```
clipmind/
├── backend/
│   ├── src/
│   │   ├── server.js                    # Express principal
│   │   ├── routes/
│   │   │   ├── auth.js                  # Login/signup
│   │   │   ├── process.js               # Upload → processamento
│   │   │   ├── clips.js                 # Listar/baixar
│   │   │   └── billing.js               # Planos/checkout
│   │   ├── services/
│   │   │   ├── youtube.js               # yt-dlp wrapper
│   │   │   ├── transcription.js         # Whisper API
│   │   │   ├── clipAnalysis.js          # Claude Haiku
│   │   │   ├── videoEditing.js          # FFmpeg wrapper
│   │   │   ├── storage.js               # Supabase Storage
│   │   │   └── payment.js               # Mercado Pago
│   │   ├── jobs/
│   │   │   └── cleanup.js               # Delete videos após 30 dias
│   │   ├── middleware/
│   │   │   ├── auth.js                  # JWT validation
│   │   │   └── errorHandler.js          # Error handling
│   │   └── utils/
│   │       ├── logger.js                # Logging
│   │       └── validators.js            # Input validation
│   ├── .env.example
│   ├── .gitignore
│   ├── package.json
│   └── Dockerfile (pra Railway)
│
├── frontend/
│   ├── index.html                       # Landing + app
│   ├── css/
│   │   └── style.css                    # Design (azul/dourado)
│   ├── js/
│   │   ├── app.js                       # App controller
│   │   ├── auth.js                      # Login/logout
│   │   ├── processor.js                 # Upload form
│   │   ├── dashboard.js                 # Lista de clips
│   │   └── supabase.js                  # Supabase client
│   └── assets/
│       ├── logo.svg                     # Ícone ClipMind
│       └── fonts/                       # Fonts
│
└── README.md
```

---

## 🔑 VARIÁVEIS DE AMBIENTE (.env.local)

```env
# SUPABASE
SUPABASE_URL=https://xxxxx.supabase.co
SUPABASE_ANON_KEY=eyJxxxxxxx
SUPABASE_SERVICE_ROLE_KEY=eyJxxxxxxx

# OPENAI
OPENAI_API_KEY=sk-xxxxxxxxxxxxx

# ANTHROPIC
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxx

# MERCADO PAGO
MERCADO_PAGO_ACCESS_TOKEN=APP_xxxxxxxxxxxxx
MERCADO_PAGO_PUBLIC_KEY=APP_PUBLIC_xxxxxxxxxxxxx

# SERVER
PORT=8080
NODE_ENV=production
BASE_URL=https://clipmind.com
WEBHOOK_SECRET=seu_secret_aleatorio

# STORAGE
VIDEO_RETENTION_DAYS=30
MAX_VIDEO_SIZE_MB=500
```

---

## 🚀 WORKFLOW DE DEPLOYMENT

### Local
```bash
# 1. Clone
git clone https://github.com/Luiza140528/clipmind.git
cd clipmind/backend

# 2. Install
npm install

# 3. Setup .env local
cp .env.example .env.local
# ... preenche as variáveis

# 4. Run local
npm start
# Backend roda em http://localhost:8080
```

### Production (Railway)
```bash
# 1. Push pra GitHub
git push origin main

# 2. Railway detecta novo push
# 3. Build automático (npm install + npm start)
# 4. Deploy automático
# 5. URL: https://clipmind-backend-production.up.railway.app
```

### Frontend (Netlify)
```bash
# 1. Conecta ao GitHub
# 2. Netlify detecta push em /frontend
# 3. Build: nada (é HTML/JS puro)
# 4. Deploy automático
# 5. URL: https://clipmind.netlify.app
```

---

## 🔗 CONNECTIONS CHECKLIST

Antes de codar, você precisa ter:

- [ ] **Supabase:** Conta ativa, projeto criado
  - [ ] URL do projeto
  - [ ] Anon key
  - [ ] Service role key
  
- [ ] **OpenAI:** API key ativa (pra Whisper)
  - [ ] Crédito suficiente

- [ ] **Anthropic:** API key ativa (pra Claude Haiku)
  - [ ] Crédito suficiente

- [ ] **Mercado Pago:** Conta de desenvolvedor
  - [ ] Access token (production)
  - [ ] Public key

- [ ] **Railway:** Conta ativa
  - [ ] Projeto criado
  - [ ] GitHub conectado

- [ ] **GitHub:** Repositório privado
  - [ ] Secrets configurados (API keys)

- [ ] **Netlify:** Conta ativa
  - [ ] Repositório GitHub conectado

---

## 💰 CUSTOS ESTIMADOS (MVP)

### Variável (por uso)
| Serviço | Uso | Preço |
|---------|-----|-------|
| **Whisper** | 100 horas áudio/mês | $120 |
| **Claude Haiku** | 1M tokens/mês | $0.80 |
| **Supabase Storage** | 100GB/mês | $10 |
| **Supabase Bandwidth** | 50GB/mês | $5 |
| **Total variável** | | **~$135/mês** |

### Fixo
| Serviço | Preço |
|---------|-------|
| **Railway** | $5/mês (free tier) |
| **Netlify** | $0/mês (free tier) |
| **Domínio** | $12/ano |
| **Total fixo** | **~$5/mês** |

**Total MVP:** ~$140/mês

**Com 100 usuários pagando R$70/mês:** R$7.000/mês - $140/mês = **R$6.860 lucro puro**

---

## ⚠️ RISCOS E MITIGAÇÃO

### Risco #1: Whisper API fora/lenta
**Mitigação:** Implementar fallback pra `faster-whisper` (local)

### Risco #2: Railway cai
**Mitigação:** Setup backup em Vercel ou AWS Lambda (depois)

### Risco #3: FFmpeg quebra em Railway
**Mitigação:** Testar com Dockerfile. Se não funcionar, usar API (Shotstack)

### Risco #4: Supabase Storage cheio
**Mitigação:** Cron job deleta videos após 30 dias

### Risco #5: Mercado Pago webhook cai
**Mitigação:** Implementar retry + polling (verificar status a cada hora)

---

## ✅ ANTES DE COMEÇAR A CODAR

**Confirme comigo:**

1. ✅ Você tem acesso a TODAS essas contas? (Supabase, OpenAI, Anthropic, Mercado Pago, Railway, GitHub, Netlify)
2. ✅ Você quer começar agora mesmo com o server.js?
3. ✅ Você quer que eu crie o repo no GitHub pra você?
4. ✅ Você quer backend + frontend em paralelo ou backend primeiro?

---

**Status:** Stack revisada e confirmada
**Próximo:** Começar o código
