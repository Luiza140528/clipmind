# 💳 Guia de Integração Mercado Pago - ClipMind

**Objetivo:** Integrar pagamentos recorrentes (subscriptions) com Mercado Pago

---

## 📋 PRÉ-REQUISITOS

1. ✅ Conta Mercado Pago (criar em https://www.mercadopago.com.br)
2. ✅ Access Token (obtém em Devs → Credenciais)
3. ✅ Public Key (obtém em Devs → Credenciais)

---

## 🔧 SETUP

### Passo 1: Obter Credenciais Mercado Pago

1. Acesse https://www.mercadopago.com.br/developers
2. Faça login com sua conta
3. Vá em "Credenciais" ou "API Keys"
4. Copie:
   - **Access Token (Produção)** → `MERCADO_PAGO_ACCESS_TOKEN`
   - **Public Key** → `MERCADO_PAGO_PUBLIC_KEY`

### Passo 2: Adicionar ao `.env.local`

```env
MERCADO_PAGO_ACCESS_TOKEN=APP_prod_xxxxxxxxxxxxx
MERCADO_PAGO_PUBLIC_KEY=APP_PUBLIC_xxxxxxxxxxxxx
```

### Passo 3: Instalar Dependência

```bash
npm install axios
```

(Axios já deve estar no package.json)

### Passo 4: Integrar no server.js

No seu `src/server.js`, adicione:

```javascript
const billingRoutes = require('./routes/billing');

// ... depois de outros middleware ...

app.use('/api/webhooks', billingRoutes);
app.use('/api/billing', billingRoutes);
```

---

## 🔌 ENDPOINTS

### 1. POST `/api/billing/checkout`

**Criar preferência de pagamento (redirecionar user pro MP)**

```javascript
// Request
{
  "plan_id": "starter", // ou "pro", "agency", "free"
  "user_email": "politico@email.com"
}

// Response (se pago)
{
  "success": true,
  "preference_id": "123456789",
  "checkout_url": "https://www.mercadopago.com.br/checkout/..." // redirecionar aqui
}

// Response (se free)
{
  "success": true,
  "message": "Free plan activated",
  "redirect_url": "https://clipmind.com?plan=free"
}
```

### 2. POST `/api/webhooks/mercado-pago`

**Webhook - Mercado Pago notifica quando pagamento é aprovado**

Mercado Pago automaticamente faz POST aqui quando:
- ✅ Pagamento aprovado
- ⏳ Pagamento pendente (boleto, pix)
- ❌ Pagamento rejeitado

**Você não precisa chamar isso**, Mercado Pago chama automaticamente.

### 3. GET `/api/billing/status`

**Verificar status da subscription do user**

```javascript
// Request
GET /api/billing/status
Headers: Authorization: Bearer {token}

// Response
{
  "user_id": "uuid-123",
  "plan": "starter",
  "credits": 30,
  "subscription": {
    "id": "uuid",
    "status": "active", // ou "pending", "cancelled"
    "started_at": "2026-06-15T10:30:00Z",
    "renews_at": "2026-07-15T10:30:00Z"
  }
}
```

### 4. POST `/api/billing/cancel`

**Cancelar subscription**

```javascript
// Request
POST /api/billing/cancel
Headers: Authorization: Bearer {token}

// Response
{
  "success": true
}
```

---

## 🧪 TESTAR LOCALMENTE

### Teste 1: Criar Checkout (Free)

```bash
curl -X POST http://localhost:8080/api/billing/checkout \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer test-token" \
  -d '{
    "plan_id": "free",
    "user_email": "test@test.com"
  }'
```

**Esperado:** Retorna `redirect_url` (porque é free)

### Teste 2: Criar Checkout (Starter)

```bash
curl -X POST http://localhost:8080/api/billing/checkout \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer test-token" \
  -d '{
    "plan_id": "starter",
    "user_email": "test@test.com"
  }'
```

**Esperado:** Retorna `checkout_url` (link do MP)

### Teste 3: Verificar Status

```bash
curl -X GET http://localhost:8080/api/billing/status \
  -H "Authorization: Bearer test-token"
```

**Esperado:** Retorna status da subscription

---

## 🎯 FLUXO COMPLETO (VISUAL)

```
USER CLICA "ASSINAR"
         ↓
    /api/billing/checkout
         ↓
SERVER CRIA PREFERENCE NO MP
         ↓
RETORNA CHECKOUT_URL
         ↓
USER REDIRECIONA PRO MP
         ↓
USER FAZ PAGAMENTO
         ↓
MP APROVA PAGAMENTO
         ↓
MP FAZ POST /api/webhooks/mercado-pago
         ↓
SERVER ATUALIZA SUBSCRIPTION (ativo)
         ↓
USER RECEBE ACESSO AO PLANO
```

---

## 💰 PLANOS (DEFINIDOS NO CODE)

| Plano | Preço | Créditos | Cortes/mês |
|-------|-------|----------|-----------|
| Free | R$0 | 3 | 3 |
| Starter | R$47 | 30 | 30 |
| Pro | R$97 | 999 | ilimitado |
| Agência | R$297 | 9999 | ilimitado |

Para mudar preços, edite `mercado-pago.js` na seção `PLANS`.

---

## 🔐 SEGURANÇA

### Validar Webhooks (Recomendado)

Mercado Pago envia `X-Signature` header. Para validar:

```javascript
const crypto = require('crypto');

function validateWebhookSignature(body, signature, secret) {
  const hash = crypto
    .createHmac('sha256', secret)
    .update(JSON.stringify(body))
    .digest('hex');
  
  return hash === signature;
}
```

Adicione isso em `billing-routes.js` se quiser extra security.

---

## 📊 BANCO DE DADOS

Tabelas necessárias (já em `schema.sql`):

```sql
subscriptions (
  id, user_id, plan, mercado_pago_id, 
  status, started_at, renews_at, cancelled_at
)

mercado_pago_preferences (
  user_id, preference_id, plan_id, status
)
```

---

## ✅ CHECKLIST DEPLOY

- [ ] Access Token e Public Key em `.env.local`
- [ ] `mercado-pago.js` criado em `/src/services/`
- [ ] `billing-routes.js` criado em `/src/routes/`
- [ ] Importado em `server.js`
- [ ] Testou endpoints localmente
- [ ] Webhook URL configurada no painel MP (`https://seu-dominio.com/api/webhooks/mercado-pago`)
- [ ] Deployou no Railway
- [ ] Testou em produção

---

## 🐛 TROUBLESHOOTING

**"Invalid Access Token"**
→ Verifique se o token está correto em `.env`

**"Webhook not called"**
→ Configure Webhook URL no painel do MP: `https://seu-dominio/api/webhooks/mercado-pago`

**"User not found after payment"**
→ Verifique se o `external_reference` está sendo passado corretamente

---

**Status:** Pronto pra integração
**Próximo:** Implementar no frontend (botão de compra)
